import json
import os
import logging
import xgboost as xgb
import numpy as np

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def model_fn(model_dir):
    """Load the XGBoost model from the model directory."""
    try:
        logger.info(f"Loading model from {model_dir}")
        model_path = os.path.join(model_dir, 'xgboost_model.json')
        
        if not os.path.exists(model_path):
            logger.error(f"Model file not found at {model_path}")
            # List available files for debugging
            available_files = os.listdir(model_dir)
            logger.error(f"Available files in {model_dir}: {available_files}")
            raise FileNotFoundError(f"Model file not found at {model_path}")
        
        # Check file size
        file_size = os.path.getsize(model_path)
        logger.info(f"Model file size: {file_size} bytes")
        
        # Load XGBoost model
        model = xgb.Booster()
        model.load_model(model_path)
        logger.info("Successfully loaded XGBoost model")
        return model
        
    except Exception as e:
        logger.error(f"Error loading model: {str(e)}")
        raise

def input_fn(request_body, request_content_type='application/json'):
    """Parse input data for inference."""
    try:
        logger.info(f"Processing input with content type: {request_content_type}")
        logger.info(f"Request body type: {type(request_body)}")
        logger.info(f"Request body preview: {str(request_body)[:200]}...")
        
        if request_content_type != 'application/json':
            raise ValueError(f"Unsupported content type: {request_content_type}")
        
        # Parse JSON input
        input_data = json.loads(request_body)
        logger.info(f"Parsed input data type: {type(input_data)}")
        logger.info(f"Parsed input data: {input_data}")
        
        # Handle different input formats
        if isinstance(input_data, dict):
            # Check if it's SageMaker instances format
            if 'instances' in input_data:
                logger.info("Using SageMaker instances format")
                input_data = input_data['instances']
            else:
                # Single prediction dictionary - convert to list
                logger.info("Using single dictionary format")
                input_data = [input_data]
        elif isinstance(input_data, list):
            # Already a list - check if it's list of dicts or raw array
            if len(input_data) > 0 and isinstance(input_data[0], dict):
                logger.info("Using list of dictionaries format")
                # Keep as is
            elif len(input_data) > 0 and isinstance(input_data[0], (int, float)):
                # This is a raw array - need to convert to expected format
                logger.warning("Received raw array format - this may not work correctly")
                logger.warning("Expected format: {'esent': 1.0, 'eopenrate': 2.0, ...}")
                # For now, raise an error to help debug
                raise ValueError(
                    "Raw array format not supported. Please use dictionary format: "
                    "{'esent': 1.0, 'eopenrate': 2.0, 'eclickrate': 3.0, ...}"
                )
            else:
                logger.info("Using list format (assuming dictionaries)")
        else:
            raise ValueError(f"Input must be a dictionary or list. Got: {type(input_data)}")
        
        # Extract features in the correct order - CRITICAL: This must match training!
        expected_features = [
            'esent', 'eopenrate', 'eclickrate', 'avgorder', 'ordfreq', 
            'paperless', 'refill', 'doorstep', 'created_year', 
            'created_month', 'created_day', 'account_age_days'
        ]
        
        features_list = []
        for item in input_data:
            if not isinstance(item, dict):
                raise ValueError(f"Each input item must be a dictionary. Got: {type(item)}")
            
            # Extract features in exact order
            features = []
            missing_features = []
            
            for feature_name in expected_features:
                if feature_name in item:
                    try:
                        value = float(item[feature_name])
                        features.append(value)
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Could not convert {feature_name}={item[feature_name]} to float: {e}")
                        features.append(0.0)  # Default value
                else:
                    missing_features.append(feature_name)
                    features.append(0.0)  # Default value for missing features
            
            if missing_features:
                logger.warning(f"Missing features (using 0.0 as default): {missing_features}")
            
            features_list.append(features)
            logger.info(f"Extracted features: {features}")
        
        # Convert to numpy array and then to DMatrix
        features_array = np.array(features_list, dtype=np.float32)
        logger.info(f"Created features array with shape: {features_array.shape}")
        
        dmatrix = xgb.DMatrix(features_array)
        logger.info(f"Created DMatrix with shape: ({dmatrix.num_row()}, {dmatrix.num_col()})")
        
        return dmatrix
        
    except Exception as e:
        logger.error(f"Error in input_fn: {str(e)}")
        logger.error(f"Request body: {request_body}")
        raise

def predict_fn(input_data, model):
    """Make prediction using the loaded model."""
    try:
        logger.info(f"Making prediction with input shape: ({input_data.num_row()}, {input_data.num_col()})")
        
        # Make prediction
        predictions = model.predict(input_data)
        
        # Ensure predictions is a numpy array
        if not isinstance(predictions, np.ndarray):
            predictions = np.array([predictions])
        
        logger.info(f"Raw predictions shape: {predictions.shape}")
        logger.info(f"Raw predictions: {predictions}")
        
        return predictions
        
    except Exception as e:
        logger.error(f"Error in predict_fn: {str(e)}")
        logger.error(f"Input data type: {type(input_data)}")
        raise

def output_fn(predictions, accept='application/json'):
    """Format the prediction output."""
    try:
        logger.info(f"Formatting output with accept type: {accept}")
        logger.info(f"Predictions type: {type(predictions)}, shape: {predictions.shape}")
        
        if accept != 'application/json':
            logger.warning(f"Unsupported accept type: {accept}, defaulting to JSON")
        
        # Convert numpy array to list for JSON serialization
        if isinstance(predictions, np.ndarray):
            pred_list = predictions.tolist()
        else:
            pred_list = [float(predictions)]
        
        logger.info(f"Converted predictions to list: {pred_list}")
        
        # Create output with predictions and binary classification
        result = {
            'predictions': pred_list,
            'predicted_class': [1 if p > 0.5 else 0 for p in pred_list]
        }
        
        logger.info(f"Final output result: {result}")
        return json.dumps(result)
        
    except Exception as e:
        logger.error(f"Error in output_fn: {str(e)}")
        logger.error(f"Predictions: {predictions}")
        raise

# Local testing function
if __name__ == "__main__":
    """
    Local testing - only runs when script is executed directly
    """
    logger.info("Running local tests...")
    
    # Test model loading
    try:
        model = model_fn('.')
        logger.info("✅ Model loading test passed")
    except Exception as e:
        logger.error(f"❌ Model loading test failed: {e}")
        exit(1)
    
    # Test input processing
    test_input = json.dumps({
        'esent': 1.0, 'eopenrate': 0.5, 'eclickrate': 0.3,
        'avgorder': 100.0, 'ordfreq': 2.0, 'paperless': 1.0,
        'refill': 0.0, 'doorstep': 1.0, 'created_year': 2023.0,
        'created_month': 6.0, 'created_day': 15.0, 'account_age_days': 365.0
    })
    
    try:
        processed_input = input_fn(test_input, 'application/json')
        logger.info("✅ Input processing test passed")
        
        # Test prediction
        predictions = predict_fn(processed_input, model)
        logger.info("✅ Prediction test passed")
        
        # Test output formatting
        output = output_fn(predictions, 'application/json')
        logger.info(f"✅ Output formatting test passed: {output}")
        
    except Exception as e:
        logger.error(f"❌ Testing failed: {e}")
        exit(1)
    
    logger.info("🎯 All local tests passed!")